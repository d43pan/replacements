$(document).ready( function(){
	
	checkDOMChange();

	function checkDOMChange(){
    	replaceLinks();
    	setTimeout( checkDOMChange, 100 );
    }


	function replaceLinks(){

		var generalLink = $("a[href]");

		$.each(generalLink, function(i, value){
			//this check is super naive.  
			//Should probably improve.
			// I expect I'll turn this into a function and most of the requests for updates will show up here.
			if( $(this).data('display') && $(this).data('replaced') != 1 ){
				console.log("data-display: ", $(this).data('display') )
				$(this).attr('data-replaced', 1)
				$(this).html('<img width="200px" src="'+$(this).data('display')+'"/>')
			}	
			
		})

});